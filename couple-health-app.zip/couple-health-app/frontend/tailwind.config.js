/** @type {import('tailwindcss').Config} */
export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        // Zurückhaltende, moderne Palette statt "medizinisches Weiß-Blau"
        bg: {
          light: "#F7F6F3",
          dark: "#14151A",
        },
        card: {
          light: "#FFFFFF",
          dark: "#1E2027",
        },
        accent: {
          steps: "#6C8CFF",
          sleep: "#8B7CF6",
          heart: "#FF6B8A",
          calories: "#FFB35C",
        },
      },
      borderRadius: {
        xl2: "1.25rem",
      },
    },
  },
  plugins: [],
};
