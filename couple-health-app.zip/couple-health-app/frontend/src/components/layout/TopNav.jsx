import { NavLink } from "react-router-dom";
import { useTheme } from "../../context/ThemeContext.jsx";
import { useAuth } from "../../context/AuthContext.jsx";

const tabs = [
  { to: "/", label: "Mein Dashboard" },
  { to: "/partner", label: "Partner" },
  { to: "/vergleich", label: "Vergleich" },
];

export default function TopNav() {
  const { theme, toggleTheme } = useTheme();
  const { user, logout } = useAuth();

  return (
    <header className="sticky top-0 z-10 bg-bg-light/90 dark:bg-bg-dark/90 backdrop-blur border-b border-black/5 dark:border-white/10">
      <div className="max-w-3xl mx-auto flex items-center justify-between px-4 py-3">
        <nav className="flex gap-1 bg-card-light dark:bg-card-dark rounded-xl2 p-1">
          {tabs.map((tab) => (
            <NavLink
              key={tab.to}
              to={tab.to}
              end={tab.to === "/"}
              className={({ isActive }) =>
                `px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                  isActive
                    ? "bg-accent-steps text-white"
                    : "text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200"
                }`
              }
            >
              {tab.label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          {user && (
            <span className="text-sm text-gray-500 dark:text-gray-400 hidden sm:inline">
              {user.display_name}
            </span>
          )}
          <button
            onClick={toggleTheme}
            aria-label="Dark/Light Mode umschalten"
            className="w-9 h-9 rounded-full bg-card-light dark:bg-card-dark flex items-center justify-center text-lg"
          >
            {theme === "dark" ? "☀️" : "🌙"}
          </button>
          <button
            onClick={logout}
            className="text-sm text-gray-500 dark:text-gray-400 px-2 py-1 rounded-lg hover:bg-card-light dark:hover:bg-card-dark"
          >
            Abmelden
          </button>
        </div>
      </div>
    </header>
  );
}
