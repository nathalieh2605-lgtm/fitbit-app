import { useState } from "react";

const ranges = ["Heute", "7 Tage", "30 Tage", "3 Monate", "1 Jahr"];

// Aktuell reine UI ohne Datenanbindung — wird in späterem Schritt
// (Datenhistorie) mit echten Zeitraum-Abfragen an die Google Health API verbunden.
export default function DateRangeSelector() {
  const [active, setActive] = useState("Heute");

  return (
    <div className="flex gap-2 overflow-x-auto pb-1 mb-4">
      {ranges.map((r) => (
        <button
          key={r}
          onClick={() => setActive(r)}
          className={`whitespace-nowrap px-3 py-1 rounded-full text-sm border transition-colors ${
            active === r
              ? "bg-accent-steps text-white border-accent-steps"
              : "border-black/10 dark:border-white/10 text-gray-500 dark:text-gray-400"
          }`}
        >
          {r}
        </button>
      ))}
    </div>
  );
}
