import NoDataPlaceholder from "./NoDataPlaceholder.jsx";

export default function ActivityCard({ activity, source }) {
  if (!activity) return <NoDataPlaceholder label="Aktivität" />;

  return (
    <div className="bg-card-light dark:bg-card-dark rounded-xl2 p-4 shadow-sm">
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-medium text-gray-500 dark:text-gray-400">
          👣 Aktivität
        </span>
        {source === "MOCK" && (
          <span className="text-[10px] uppercase tracking-wide bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300 px-1.5 py-0.5 rounded">
            Mock-Daten
          </span>
        )}
      </div>

      <div className="text-2xl font-semibold">
        {activity.steps.toLocaleString("de-DE")}
        <span className="text-sm font-normal text-gray-500 dark:text-gray-400 ml-1">
          Schritte
        </span>
      </div>

      <div className="grid grid-cols-3 gap-2 mt-3 text-sm">
        <div>
          <div className="text-gray-500 dark:text-gray-400">Distanz</div>
          <div className="font-medium">{activity.distanceKm} km</div>
        </div>
        <div>
          <div className="text-gray-500 dark:text-gray-400">Aktiv</div>
          <div className="font-medium">{activity.activeMinutes} min</div>
        </div>
        <div>
          <div className="text-gray-500 dark:text-gray-400">Kalorien</div>
          <div className="font-medium">{activity.caloriesBurned}</div>
        </div>
      </div>
    </div>
  );
}
