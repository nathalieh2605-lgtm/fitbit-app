import { api } from "../../api/client.js";

export default function GoogleConnectBanner({ connected, onDisconnected }) {
  if (connected) {
    return (
      <div className="flex items-center justify-between bg-card-light dark:bg-card-dark rounded-xl2 p-3 mb-4 text-sm">
        <span className="text-green-600 dark:text-green-400">
          ✓ Mit Google Health verbunden
        </span>
        <button
          onClick={async () => {
            await api.disconnectGoogle();
            onDisconnected?.();
          }}
          className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
        >
          Trennen
        </button>
      </div>
    );
  }

  return (
    <div className="bg-card-light dark:bg-card-dark rounded-xl2 p-4 mb-4 flex items-center justify-between gap-3">
      <div>
        <div className="text-sm font-medium">Mit Google Health verbinden</div>
        <div className="text-xs text-gray-500 dark:text-gray-400">
          Aktuell werden Mock-Daten angezeigt.
        </div>
      </div>
      <a
        href={api.buildGoogleConnectUrl()}
        className="bg-accent-steps text-white text-sm font-medium rounded-lg px-3 py-2 whitespace-nowrap"
      >
        Verbinden
      </a>
    </div>
  );
}
