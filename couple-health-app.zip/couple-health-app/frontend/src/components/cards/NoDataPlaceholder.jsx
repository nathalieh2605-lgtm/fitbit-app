// Wird gezeigt, wenn ein Wert `null`/`undefined` ist — NIEMALS als "0" anzeigen.
export default function NoDataPlaceholder({ label }) {
  return (
    <div className="text-sm text-gray-400 dark:text-gray-500 italic">
      {label ? `${label}: ` : ""}Keine Daten verfügbar
    </div>
  );
}
