import NoDataPlaceholder from "./NoDataPlaceholder.jsx";

export default function SleepCard({ sleep, source }) {
  if (!sleep) return <NoDataPlaceholder label="Schlaf" />;

  const hours = Math.floor(sleep.durationMinutes / 60);
  const minutes = sleep.durationMinutes % 60;

  return (
    <div className="bg-card-light dark:bg-card-dark rounded-xl2 p-4 shadow-sm">
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-medium text-gray-500 dark:text-gray-400">
          🛌 Schlaf
        </span>
        {source === "MOCK" && (
          <span className="text-[10px] uppercase tracking-wide bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300 px-1.5 py-0.5 rounded">
            Mock-Daten
          </span>
        )}
      </div>

      <div className="text-2xl font-semibold">
        {hours}h {minutes}min
      </div>
      <div className="text-sm text-gray-500 dark:text-gray-400 mb-3">
        Schlafscore: <span className="font-medium">{sleep.score ?? "–"}</span>
      </div>

      <div className="flex h-3 rounded-full overflow-hidden">
        <div
          className="bg-accent-sleep"
          style={{ width: `${(sleep.phases.rem / sleep.durationMinutes) * 100}%` }}
          title="REM"
        />
        <div
          className="bg-accent-steps"
          style={{ width: `${(sleep.phases.light / sleep.durationMinutes) * 100}%` }}
          title="Leichtschlaf"
        />
        <div
          className="bg-indigo-800"
          style={{ width: `${(sleep.phases.deep / sleep.durationMinutes) * 100}%` }}
          title="Tiefschlaf"
        />
        <div
          className="bg-gray-300 dark:bg-gray-600"
          style={{ width: `${(sleep.phases.awake / sleep.durationMinutes) * 100}%` }}
          title="Wach"
        />
      </div>
    </div>
  );
}
