import NoDataPlaceholder from "./NoDataPlaceholder.jsx";

export default function HeartRateCard({ heart, source }) {
  if (!heart) return <NoDataPlaceholder label="Herz" />;

  return (
    <div className="bg-card-light dark:bg-card-dark rounded-xl2 p-4 shadow-sm">
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-medium text-gray-500 dark:text-gray-400">
          ❤️ Herz
        </span>
        {source === "MOCK" && (
          <span className="text-[10px] uppercase tracking-wide bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300 px-1.5 py-0.5 rounded">
            Mock-Daten
          </span>
        )}
      </div>

      <div className="grid grid-cols-2 gap-3 text-sm">
        <div>
          <div className="text-gray-500 dark:text-gray-400">Ruhepuls</div>
          <div className="text-xl font-semibold">
            {heart.restingHeartRate ?? "–"}
            {heart.restingHeartRate != null && (
              <span className="text-sm font-normal"> bpm</span>
            )}
          </div>
        </div>
        <div>
          <div className="text-gray-500 dark:text-gray-400">Ø Herzfrequenz</div>
          <div className="text-xl font-semibold">
            {heart.avgHeartRate ?? "–"}
            {heart.avgHeartRate != null && (
              <span className="text-sm font-normal"> bpm</span>
            )}
          </div>
        </div>
        <div>
          <div className="text-gray-500 dark:text-gray-400">HRV</div>
          {heart.hrv != null ? (
            <div className="font-medium">{heart.hrv} ms</div>
          ) : (
            <NoDataPlaceholder />
          )}
        </div>
        <div>
          <div className="text-gray-500 dark:text-gray-400">SpO₂</div>
          {heart.spo2 != null ? (
            <div className="font-medium">{heart.spo2}%</div>
          ) : (
            <NoDataPlaceholder />
          )}
        </div>
      </div>
    </div>
  );
}
