import { Routes, Route, Navigate } from "react-router-dom";
import { useAuth } from "./context/AuthContext.jsx";
import TopNav from "./components/layout/TopNav.jsx";
import MyDashboard from "./pages/MyDashboard.jsx";
import PartnerDashboard from "./pages/PartnerDashboard.jsx";
import Compare from "./pages/Compare.jsx";
import Login from "./pages/Login.jsx";

function ProtectedLayout({ children }) {
  const { token, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-gray-400">
        Lade …
      </div>
    );
  }
  if (!token) {
    return <Navigate to="/login" replace />;
  }
  return (
    <div className="min-h-screen">
      <TopNav />
      {children}
    </div>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route
        path="/"
        element={
          <ProtectedLayout>
            <MyDashboard />
          </ProtectedLayout>
        }
      />
      <Route
        path="/partner"
        element={
          <ProtectedLayout>
            <PartnerDashboard />
          </ProtectedLayout>
        }
      />
      <Route
        path="/vergleich"
        element={
          <ProtectedLayout>
            <Compare />
          </ProtectedLayout>
        }
      />
    </Routes>
  );
}
