import { api } from "../api/client.js";
import { useHealthData } from "../hooks/useHealthData.js";
import DateRangeSelector from "../components/layout/DateRangeSelector.jsx";
import SleepCard from "../components/cards/SleepCard.jsx";
import ActivityCard from "../components/cards/ActivityCard.jsx";
import HeartRateCard from "../components/cards/HeartRateCard.jsx";

export default function PartnerDashboard() {
  const { data, loading, error } = useHealthData(api.getPartnerDashboard, []);

  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      <h1 className="text-xl font-semibold mb-1">Mein Freund</h1>
      <p className="text-xs text-gray-400 mb-4">
        Zeigt nur Daten, die dein Partner ausdrücklich freigegeben hat.
      </p>

      <DateRangeSelector />

      {loading && <p className="text-gray-400">Lade Daten …</p>}
      {error && <p className="text-red-500">Fehler: {error}</p>}

      {data && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <SleepCard sleep={data.sleep} source={data.source} />
          <ActivityCard activity={data.activity} source={data.source} />
          <HeartRateCard heart={data.heart} source={data.source} />
        </div>
      )}
    </div>
  );
}
