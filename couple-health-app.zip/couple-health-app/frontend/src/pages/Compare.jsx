import { api } from "../api/client.js";
import { useHealthData } from "../hooks/useHealthData.js";

export default function Compare() {
  const { data, loading, error } = useHealthData(api.getComparison, []);

  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      <h1 className="text-xl font-semibold mb-4">Vergleich</h1>

      {loading && <p className="text-gray-400">Lade Daten …</p>}
      {error && <p className="text-red-500">Fehler: {error}</p>}

      {data && (
        <div className="bg-card-light dark:bg-card-dark rounded-xl2 shadow-sm overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-gray-500 dark:text-gray-400 border-b border-black/5 dark:border-white/10">
                <th className="p-3 font-medium">Kategorie</th>
                <th className="p-3 font-medium">Ich</th>
                <th className="p-3 font-medium">Partner</th>
              </tr>
            </thead>
            <tbody>
              {data.categories.map((c) => (
                <tr key={c.key} className="border-b border-black/5 dark:border-white/10 last:border-0">
                  <td className="p-3">{c.label}</td>
                  <td className="p-3 font-medium">{c.me}</td>
                  <td className="p-3 font-medium">{c.partner}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <p className="text-xs text-gray-400 mt-3">
        Hinweis: Diagramm-Vergleiche folgen in Schritt 10.
      </p>
    </div>
  );
}
