import { useState } from "react";
import { useAuth } from "../context/AuthContext.jsx";

export default function Login() {
  const { login, register } = useAuth();
  const [mode, setMode] = useState("login"); // "login" | "register"
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [error, setError] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      if (mode === "login") {
        await login(email, password);
      } else {
        await register(email, password, displayName);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="w-full max-w-sm bg-card-light dark:bg-card-dark rounded-xl2 p-6 shadow-sm">
        <h1 className="text-xl font-semibold mb-1">
          {mode === "login" ? "Anmelden" : "Konto erstellen"}
        </h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mb-5">
          Couple Health &mdash; euer privates Gesundheits-Dashboard
        </p>

        <form onSubmit={handleSubmit} className="space-y-3">
          {mode === "register" && (
            <div>
              <label className="text-sm font-medium block mb-1">Anzeigename</label>
              <input
                type="text"
                required
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full rounded-lg border border-black/10 dark:border-white/10 bg-transparent px-3 py-2 text-sm"
                placeholder="Nathalie"
              />
            </div>
          )}

          <div>
            <label className="text-sm font-medium block mb-1">E-Mail</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-lg border border-black/10 dark:border-white/10 bg-transparent px-3 py-2 text-sm"
              placeholder="du@beispiel.de"
            />
          </div>

          <div>
            <label className="text-sm font-medium block mb-1">Passwort</label>
            <input
              type="password"
              required
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-lg border border-black/10 dark:border-white/10 bg-transparent px-3 py-2 text-sm"
              placeholder="mindestens 8 Zeichen"
            />
          </div>

          {error && <p className="text-sm text-red-500">{error}</p>}

          <button
            type="submit"
            disabled={submitting}
            className="w-full bg-accent-steps text-white rounded-lg py-2 text-sm font-medium disabled:opacity-50"
          >
            {submitting
              ? "Bitte warten …"
              : mode === "login"
              ? "Anmelden"
              : "Konto erstellen"}
          </button>
        </form>

        <button
          onClick={() => {
            setError(null);
            setMode(mode === "login" ? "register" : "login");
          }}
          className="w-full text-center text-sm text-gray-500 dark:text-gray-400 mt-4"
        >
          {mode === "login"
            ? "Noch kein Konto? Jetzt registrieren"
            : "Bereits ein Konto? Anmelden"}
        </button>
      </div>
    </div>
  );
}
