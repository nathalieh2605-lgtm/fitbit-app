import { useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { api } from "../api/client.js";
import { useHealthData } from "../hooks/useHealthData.js";
import DateRangeSelector from "../components/layout/DateRangeSelector.jsx";
import SleepCard from "../components/cards/SleepCard.jsx";
import ActivityCard from "../components/cards/ActivityCard.jsx";
import HeartRateCard from "../components/cards/HeartRateCard.jsx";
import GoogleConnectBanner from "../components/cards/GoogleConnectBanner.jsx";

export default function MyDashboard() {
  const { data, loading, error, refetch } = useHealthData(api.getMyDashboard, []);
  const [searchParams, setSearchParams] = useSearchParams();

  const googleError = searchParams.get("google_error");
  const justConnected = searchParams.get("google_connected");

  useEffect(() => {
    if (googleError || justConnected) {
      if (justConnected) refetch();
      setSearchParams({}, { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="max-w-3xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-1">
        <h1 className="text-xl font-semibold">Mein Dashboard</h1>
        {data && !loading && (
          <span className="text-xs text-gray-400">
            {data.googleConnected
              ? "Live-Daten"
              : `Zuletzt synchronisiert: vor ${data.lastSyncedMinutesAgo} Minuten`}
          </span>
        )}
      </div>

      {googleError && (
        <p className="text-sm text-red-500 mb-2">
          Google-Verbindung fehlgeschlagen: {googleError}
        </p>
      )}

      {data && (
        <GoogleConnectBanner connected={data.googleConnected} onDisconnected={refetch} />
      )}

      <DateRangeSelector />

      {loading && <p className="text-gray-400">Lade Daten …</p>}
      {error && <p className="text-red-500">Fehler: {error}</p>}

      {data && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <SleepCard sleep={data.sleep} source={data.source} />
          <ActivityCard activity={data.activity} source={data.source} />
          <HeartRateCard heart={data.heart} source={data.source} />
        </div>
      )}
    </div>
  );
}
