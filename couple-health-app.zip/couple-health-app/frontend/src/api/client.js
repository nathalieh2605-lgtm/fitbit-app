const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4000";

async function request(path) {
  const token = localStorage.getItem("token");
  const res = await fetch(`${API_URL}${path}`, {
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  });
  if (!res.ok) {
    throw new Error(`API-Fehler ${res.status} bei ${path}`);
  }
  return res.json();
}

export const api = {
  getMyDashboard: () => request("/api/dashboard/me"),
  getPartnerDashboard: () => request("/api/dashboard/partner"),
  getComparison: () => request("/api/compare"),
  getGoogleStatus: () => request("/api/auth/google/status"),
  buildGoogleConnectUrl: () => {
    const token = localStorage.getItem("token");
    return `${API_URL}/api/auth/google/start?token=${encodeURIComponent(token)}`;
  },
  disconnectGoogle: async () => {
    const token = localStorage.getItem("token");
    const res = await fetch(`${API_URL}/api/auth/google`, {
      method: "DELETE",
      headers: { Authorization: `Bearer ${token}` },
    });
    if (!res.ok) throw new Error("Trennen fehlgeschlagen");
    return res.json();
  },
};
