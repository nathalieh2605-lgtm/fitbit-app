-- 002_create_oauth_connections.sql
-- Speichert die Google-OAuth-Verbindung pro App-Nutzer.
-- access_token/refresh_token liegen NUR verschlüsselt in der DB
-- (siehe backend/src/services/tokenEncryption.js).

CREATE TABLE IF NOT EXISTS oauth_connections (
  id                    SERIAL PRIMARY KEY,
  user_id               INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  provider              VARCHAR(30) NOT NULL DEFAULT 'google',
  access_token_encrypted  TEXT NOT NULL,
  refresh_token_encrypted TEXT,
  scope                 TEXT NOT NULL,
  expires_at            TIMESTAMPTZ NOT NULL,
  created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, provider)
);
