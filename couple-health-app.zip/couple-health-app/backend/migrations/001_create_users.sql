-- 001_create_users.sql
-- App-eigene Nutzerkonten (getrennt von der Google-OAuth-Verbindung, die in
-- Schritt 6 dazukommt). Ein App-Konto kann später mit einem Google-Konto
-- verknüpft werden, ist aber technisch unabhängig davon.

CREATE TABLE IF NOT EXISTS users (
  id            SERIAL PRIMARY KEY,
  email         VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  display_name  VARCHAR(100) NOT NULL,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
