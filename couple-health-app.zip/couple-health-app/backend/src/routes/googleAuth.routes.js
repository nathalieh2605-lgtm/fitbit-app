import { Router } from "express";
import { start, callback, status, disconnect } from "../controllers/googleAuthController.js";
import { requireAuth } from "../middleware/requireAuth.js";
import { asyncHandler } from "../middleware/asyncHandler.js";

const router = Router();

router.get("/start", start); // eigene Token-Prüfung via Query-Param, siehe Controller
router.get("/callback", asyncHandler(callback)); // von Google aufgerufen, kein App-Login möglich
router.get("/status", requireAuth, asyncHandler(status));
router.delete("/", requireAuth, asyncHandler(disconnect));

export default router;
