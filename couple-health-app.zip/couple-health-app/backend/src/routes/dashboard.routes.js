import { Router } from "express";
import { getMockDashboard } from "../services/mockHealthData.js";
import { fetchTodayHealthData, getValidAccessToken } from "../services/googleHealthApi.js";
import { mapGoogleHealthDataToDashboard } from "../services/dataMapper.js";
import { getGoogleConnection, saveGoogleConnection } from "../models/OAuthConnection.js";
import { requireAuth } from "../middleware/requireAuth.js";
import { asyncHandler } from "../middleware/asyncHandler.js";

const router = Router();
router.use(requireAuth);

// GET /api/dashboard/me
// Liefert echte Daten aus der Google Health API, sobald der Nutzer
// verbunden ist. Ohne Verbindung: klar markierte Mock-Daten, damit das
// Dashboard trotzdem nutzbar bleibt.
router.get(
  "/me",
  asyncHandler(async (req, res) => {
    const connection = await getGoogleConnection(req.userId);

    if (!connection) {
      return res.json({ ...getMockDashboard("Ich"), googleConnected: false });
    }

    try {
      const accessToken = await getValidAccessToken(req.userId, connection, saveGoogleConnection);
      const raw = await fetchTodayHealthData(accessToken);
      const mapped = mapGoogleHealthDataToDashboard(raw, 0);
      res.json({ ...mapped, googleConnected: true });
    } catch (err) {
      console.error("Fehler beim Abruf der Google Health-Daten:", err.message);
      res.status(502).json({
        error: "Google-Daten konnten nicht abgerufen werden. Bitte erneut synchronisieren.",
        detail: err.message,
        googleConnected: true,
      });
    }
  })
);

// GET /api/dashboard/partner
// Bleibt vorerst Mock-Daten — echte Partner-Daten kommen mit dem
// Sharing-System in Schritt 8.
router.get("/partner", (req, res) => {
  res.json({ ...getMockDashboard("Partner"), googleConnected: false });
});

export default router;
