import { Router } from "express";
import { requireAuth } from "../middleware/requireAuth.js";

const router = Router();
router.use(requireAuth);

// GET /api/compare
// Liefert aktuell Mock-Vergleichsdaten für beide Nutzer.
// Wird in späterem Schritt durch echte, per Sharing-Permission gefilterte
// Daten aus beiden Google Health API-Konten ersetzt.
router.get("/", (req, res) => {
  res.json({
    source: "MOCK",
    range: "today",
    categories: [
      { key: "steps", label: "Schritte", me: 8432, partner: 10214 },
      { key: "sleepMinutes", label: "Schlaf (Min)", me: 441, partner: 468 },
      { key: "sleepScore", label: "Schlafscore", me: 82, partner: 89 },
      { key: "restingHeartRate", label: "Ruhepuls", me: 61, partner: 58 },
      { key: "calories", label: "Kalorien", me: 1842, partner: 2103 },
      { key: "activeMinutes", label: "Aktive Minuten", me: 54, partner: 72 },
    ],
  });
});

export default router;
