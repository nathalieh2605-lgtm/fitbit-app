import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { findUserByEmail, findUserById, createUser } from "../models/User.js";

const JWT_EXPIRES_IN = "30d";

function signToken(user) {
  return jwt.sign(
    { userId: user.id, email: user.email },
    process.env.JWT_SECRET,
    { expiresIn: JWT_EXPIRES_IN }
  );
}

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export async function register(req, res) {
  const { email, password, displayName } = req.body;

  if (!email || !password || !displayName) {
    return res
      .status(400)
      .json({ error: "E-Mail, Passwort und Anzeigename sind erforderlich." });
  }
  if (!isValidEmail(email)) {
    return res.status(400).json({ error: "Ungültige E-Mail-Adresse." });
  }
  if (password.length < 8) {
    return res
      .status(400)
      .json({ error: "Passwort muss mindestens 8 Zeichen lang sein." });
  }

  const existing = await findUserByEmail(email);
  if (existing) {
    return res.status(409).json({ error: "Diese E-Mail ist bereits registriert." });
  }

  const passwordHash = await bcrypt.hash(password, 12);
  const user = await createUser({ email, passwordHash, displayName });
  const token = signToken(user);

  res.status(201).json({ token, user });
}

export async function login(req, res) {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: "E-Mail und Passwort sind erforderlich." });
  }

  const user = await findUserByEmail(email);
  if (!user) {
    return res.status(401).json({ error: "E-Mail oder Passwort falsch." });
  }

  const passwordMatches = await bcrypt.compare(password, user.password_hash);
  if (!passwordMatches) {
    return res.status(401).json({ error: "E-Mail oder Passwort falsch." });
  }

  const token = signToken(user);
  const { password_hash, ...safeUser } = user;

  res.json({ token, user: safeUser });
}

export async function me(req, res) {
  const user = await findUserById(req.userId);
  if (!user) {
    return res.status(404).json({ error: "Nutzer nicht gefunden." });
  }
  res.json({ user });
}
