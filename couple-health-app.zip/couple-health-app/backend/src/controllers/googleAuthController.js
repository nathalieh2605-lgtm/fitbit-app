import jwt from "jsonwebtoken";
import {
  buildGoogleAuthUrl,
  exchangeCodeForTokens,
} from "../services/googleHealthApi.js";
import {
  saveGoogleConnection,
  getGoogleConnection,
  deleteGoogleConnection,
} from "../models/OAuthConnection.js";

const FRONTEND_URL = process.env.FRONTEND_URL || "http://localhost:5173";

/**
 * GET /api/auth/google/start?token=<jwt>
 *
 * Wird per Browser-Navigation aufgerufen (Link/Button-Klick), nicht per
 * fetch() — deshalb kann hier kein Authorization-Header mitgeschickt werden.
 * Der App-JWT kommt daher als Query-Parameter und wird hier verifiziert.
 *
 * Sicherheitshinweis: Für den produktiven Einsatz sollte das durch ein
 * kurzlebiges Einmal-Token ersetzt werden (statt des vollen 30-Tage-JWTs
 * in der URL), um das Risiko durch Browser-Verlauf/Logs zu minimieren.
 */
export function start(req, res) {
  const { token } = req.query;
  if (!token) {
    return res.status(401).send("Nicht angemeldet.");
  }

  let payload;
  try {
    payload = jwt.verify(token, process.env.JWT_SECRET);
  } catch {
    return res.status(401).send("Sitzung ungültig.");
  }

  // state trägt die userId signiert weiter, damit der Callback weiß,
  // welchem App-Nutzer die Google-Verbindung zugeordnet werden muss.
  const state = jwt.sign({ userId: payload.userId }, process.env.JWT_SECRET, {
    expiresIn: "10m",
  });

  const url = buildGoogleAuthUrl({ state });
  res.redirect(url);
}

/**
 * GET /api/auth/google/callback
 */
export async function callback(req, res) {
  const { code, state, error } = req.query;

  if (error) {
    return res.redirect(`${FRONTEND_URL}/?google_error=${encodeURIComponent(error)}`);
  }
  if (!code || !state) {
    return res.redirect(`${FRONTEND_URL}/?google_error=missing_code_or_state`);
  }

  let statePayload;
  try {
    statePayload = jwt.verify(state, process.env.JWT_SECRET);
  } catch {
    return res.redirect(`${FRONTEND_URL}/?google_error=invalid_state`);
  }

  try {
    const tokens = await exchangeCodeForTokens(code);
    const expiresAt = new Date(Date.now() + tokens.expires_in * 1000);

    await saveGoogleConnection(statePayload.userId, {
      accessToken: tokens.access_token,
      refreshToken: tokens.refresh_token || null,
      scope: tokens.scope,
      expiresAt,
    });

    res.redirect(`${FRONTEND_URL}/?google_connected=true`);
  } catch (err) {
    console.error("Google OAuth Callback-Fehler:", err.message);
    res.redirect(`${FRONTEND_URL}/?google_error=${encodeURIComponent(err.message)}`);
  }
}

/**
 * GET /api/auth/google/status  (requireAuth)
 */
export async function status(req, res) {
  const connection = await getGoogleConnection(req.userId);
  res.json({ connected: !!connection });
}

/**
 * DELETE /api/auth/google  (requireAuth)
 */
export async function disconnect(req, res) {
  await deleteGoogleConnection(req.userId);
  res.json({ disconnected: true });
}
