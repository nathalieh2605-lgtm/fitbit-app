// Fängt Fehler aus async Route-Handlern ab und reicht sie an Express'
// Error-Handling-Middleware weiter, statt den Prozess abstürzen zu lassen.
export function asyncHandler(fn) {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}
