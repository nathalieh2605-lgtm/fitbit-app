/**
 * MOCK-DATEN — ausschließlich für die Entwicklung von Schritt 4.
 *
 * Diese Daten sind FREI ERFUNDEN und stellen KEINE echten Gesundheitsdaten dar.
 * Jede Response, die auf diesen Daten basiert, wird über das Feld
 * `source: "MOCK"` gekennzeichnet, damit Frontend und Nutzer:in jederzeit
 * erkennen können, dass es sich nicht um echte Fitbit-/Google-Daten handelt.
 *
 * Wird in Schritt 6 vollständig durch echte Aufrufe an die Google Health API
 * ersetzt (siehe backend/src/services/googleHealthApi.js, folgt dann).
 */

export function getMockDashboard(userLabel = "Ich") {
  return {
    source: "MOCK",
    label: userLabel,
    lastSyncedMinutesAgo: 8,
    sleep: {
      durationMinutes: 441,
      score: 82,
      phases: { rem: 96, light: 231, deep: 78, awake: 36 },
    },
    activity: {
      steps: 8432,
      distanceKm: 6.1,
      activeMinutes: 54,
      caloriesBurned: 1842,
    },
    heart: {
      restingHeartRate: 61,
      avgHeartRate: 74,
      hrv: null, // absichtlich null -> "Keine Daten verfügbar", nicht 0
      spo2: null,
    },
  };
}
