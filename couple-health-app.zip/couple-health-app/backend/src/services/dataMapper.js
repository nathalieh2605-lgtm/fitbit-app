/**
 * Übersetzt die Rohantworten der Google Health API in das gleiche Format,
 * das auch mockHealthData.js liefert – damit Frontend und Dashboard-Routen
 * nicht wissen müssen, ob Mock- oder echte Daten reinkommen.
 *
 * WICHTIG: Fehlt ein Wert, wird konsequent `null` gesetzt statt 0
 * ("Keine Daten verfügbar" statt falscher Nullwerte).
 */
export function mapGoogleHealthDataToDashboard(raw, lastSyncedMinutesAgo) {
  const activity = raw.activity?.rollupValue ?? null;
  const sleep = raw.sleep?.rollupValue ?? null;

  return {
    source: "GOOGLE_HEALTH_API",
    lastSyncedMinutesAgo,
    sleep: sleep
      ? {
          durationMinutes: sleep.sleepDurationMinutes ?? null,
          score: sleep.sleepScore ?? null,
          phases: {
            rem: sleep.remMinutes ?? 0,
            light: sleep.lightSleepMinutes ?? 0,
            deep: sleep.deepSleepMinutes ?? 0,
            awake: sleep.awakeMinutes ?? 0,
          },
        }
      : null,
    activity: activity
      ? {
          steps: activity.steps ?? null,
          distanceKm: activity.distanceMeters != null ? activity.distanceMeters / 1000 : null,
          activeMinutes: activity.activeMinutes ?? null,
          caloriesBurned: activity.caloriesBurned ?? null,
        }
      : null,
    heart: {
      restingHeartRate: raw.restingHr?.rollupValue?.bpm ?? null,
      avgHeartRate: activity?.averageHeartRate ?? null,
      hrv: raw.hrv?.rollupValue?.rmssdMillis ?? null,
      spo2: raw.spo2?.rollupValue?.percentage ?? null,
    },
  };
}
