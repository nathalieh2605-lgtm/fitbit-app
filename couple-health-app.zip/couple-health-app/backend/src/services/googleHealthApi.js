/**
 * Anbindung an die GOOGLE HEALTH API (health.googleapis.com/v4), Stand 09/2026.
 * Nachfolger der Fitbit Web API, die am 30.09.2026 abgeschaltet wird.
 *
 * Doku: https://developers.google.com/health
 */

const GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth";
const GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token";
const HEALTH_API_BASE = "https://health.googleapis.com/v4";

// Scopes, die wir für die im Konzept gewünschten Datentypen brauchen.
export const GOOGLE_HEALTH_SCOPES = [
  "https://www.googleapis.com/auth/googlehealth.activity_and_fitness.readonly",
  "https://www.googleapis.com/auth/googlehealth.health_metrics_and_measurements.readonly",
  "openid",
  "email",
];

export function buildGoogleAuthUrl({ state }) {
  const params = new URLSearchParams({
    client_id: process.env.GOOGLE_CLIENT_ID,
    redirect_uri: process.env.GOOGLE_REDIRECT_URI,
    response_type: "code",
    access_type: "offline", // notwendig, um ein refresh_token zu bekommen
    prompt: "consent", // erzwingt erneuten Consent -> stellt sicher, dass wir ein refresh_token erhalten
    scope: GOOGLE_HEALTH_SCOPES.join(" "),
    state,
  });
  return `${GOOGLE_AUTH_URL}?${params.toString()}`;
}

export async function exchangeCodeForTokens(code) {
  const res = await fetch(GOOGLE_TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      code,
      client_id: process.env.GOOGLE_CLIENT_ID,
      client_secret: process.env.GOOGLE_CLIENT_SECRET,
      redirect_uri: process.env.GOOGLE_REDIRECT_URI,
      grant_type: "authorization_code",
    }),
  });

  const data = await res.json();
  if (!res.ok) {
    throw new Error(`Google Token-Austausch fehlgeschlagen: ${data.error_description || data.error}`);
  }
  return data; // { access_token, refresh_token, expires_in, scope, token_type }
}

export async function refreshAccessToken(refreshToken) {
  const res = await fetch(GOOGLE_TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      refresh_token: refreshToken,
      client_id: process.env.GOOGLE_CLIENT_ID,
      client_secret: process.env.GOOGLE_CLIENT_SECRET,
      grant_type: "refresh_token",
    }),
  });

  const data = await res.json();
  if (!res.ok) {
    throw new Error(`Google Token-Refresh fehlgeschlagen: ${data.error_description || data.error}`);
  }
  return data; // { access_token, expires_in, scope, ... } (kein neues refresh_token)
}

/**
 * Holt einen gültigen Access-Token für den Nutzer. Erneuert ihn automatisch
 * über den Refresh-Token, falls er abgelaufen ist, und speichert das
 * Ergebnis direkt wieder verschlüsselt in der DB.
 */
export async function getValidAccessToken(userId, connection, saveConnectionFn) {
  const now = new Date();
  const expiresAt = new Date(connection.expiresAt);

  if (expiresAt > now) {
    return connection.accessToken;
  }

  if (!connection.refreshToken) {
    throw new Error(
      "Google-Verbindung abgelaufen und kein Refresh-Token vorhanden. Bitte neu verbinden."
    );
  }

  const refreshed = await refreshAccessToken(connection.refreshToken);
  const newExpiresAt = new Date(Date.now() + refreshed.expires_in * 1000);

  await saveConnectionFn(userId, {
    accessToken: refreshed.access_token,
    refreshToken: null, // COALESCE in OAuthConnection.js behält den alten
    scope: refreshed.scope || connection.scope,
    expiresAt: newExpiresAt,
  });

  return refreshed.access_token;
}

async function callHealthApi(accessToken, path) {
  const res = await fetch(`${HEALTH_API_BASE}${path}`, {
    headers: { Authorization: `Bearer ${accessToken}` },
  });

  if (res.status === 404) return null; // Datentyp für diesen Nutzer nicht vorhanden
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Google Health API-Fehler (${res.status}): ${text}`);
  }
  return res.json();
}

/**
 * Ruft die heutigen Rollup-Werte für Aktivität, Schlaf und Herz ab und
 * bringt sie in unser einheitliches App-Format (siehe dataMapper.js).
 * Gibt für nicht verfügbare Felder konsequent `null` zurück
 * (NIE 0 als Platzhalter).
 */
export async function fetchTodayHealthData(accessToken) {
  const today = new Date().toISOString().slice(0, 10);

  const [activity, sleep, restingHr, hrv, spo2] = await Promise.all([
    callHealthApi(accessToken, `/users/me/dataTypes/activityLevel:dailyRollup?date=${today}`),
    callHealthApi(accessToken, `/users/me/dataTypes/sleepSummary:dailyRollup?date=${today}`),
    callHealthApi(accessToken, `/users/me/dataTypes/dailyRestingHeartRate?date=${today}`),
    callHealthApi(accessToken, `/users/me/dataTypes/heartRateVariability:dailyRollup?date=${today}`),
    callHealthApi(accessToken, `/users/me/dataTypes/oxygenSaturation:dailyRollup?date=${today}`),
  ]);

  return { activity, sleep, restingHr, hrv, spo2, rawDate: today };
}
