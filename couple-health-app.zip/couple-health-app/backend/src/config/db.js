import pg from "pg";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const { Pool } = pg;
const __dirname = path.dirname(fileURLToPath(import.meta.url));

// DATABASE_URL kommt entweder von docker-compose oder aus backend/.env
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

pool.on("error", (err) => {
  console.error("Unerwarteter PostgreSQL-Fehler:", err);
});

export async function checkDbConnection() {
  try {
    await pool.query("SELECT 1");
    return true;
  } catch (err) {
    console.error("DB-Verbindung fehlgeschlagen:", err.message);
    return false;
  }
}

/**
 * Sehr einfacher Migrations-Runner für die Entwicklungsphase:
 * führt alle .sql-Dateien aus /migrations der Reihe nach aus.
 * Die Dateien selbst nutzen CREATE TABLE IF NOT EXISTS und sind
 * damit gefahrlos mehrfach ausführbar.
 * Für Produktion später ggf. durch ein echtes Tool (z. B. node-pg-migrate)
 * ersetzen.
 */
export async function runMigrations() {
  const migrationsDir = path.join(__dirname, "../../migrations");
  if (!fs.existsSync(migrationsDir)) return;

  const files = fs
    .readdirSync(migrationsDir)
    .filter((f) => f.endsWith(".sql"))
    .sort();

  for (const file of files) {
    const sql = fs.readFileSync(path.join(migrationsDir, file), "utf-8");
    try {
      await pool.query(sql);
      console.log(`Migration angewendet: ${file}`);
    } catch (err) {
      console.error(`Migration fehlgeschlagen (${file}):`, err.message);
      throw err;
    }
  }
}

export default pool;
