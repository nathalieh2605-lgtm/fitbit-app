import "dotenv/config";
import express from "express";
import cors from "cors";
import { checkDbConnection, runMigrations } from "./config/db.js";
import authRoutes from "./routes/auth.routes.js";
import googleAuthRoutes from "./routes/googleAuth.routes.js";
import dashboardRoutes from "./routes/dashboard.routes.js";
import compareRoutes from "./routes/compare.routes.js";

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

app.get("/health", async (req, res) => {
  const dbOk = await checkDbConnection();
  res.json({
    status: "ok",
    dbConnected: dbOk,
    timestamp: new Date().toISOString(),
  });
});

app.use("/api/auth", authRoutes);
app.use("/api/auth/google", googleAuthRoutes);
app.use("/api/dashboard", dashboardRoutes);
app.use("/api/compare", compareRoutes);

// Zentrale Error-Middleware: fängt alles ab, was asyncHandler durchreicht
// (und was Express selbst wirft), damit ein einzelner fehlerhafter Request
// niemals den ganzen Server abschießt.
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error("Unbehandelter Fehler:", err);
  if (res.headersSent) return next(err);
  res.status(500).json({ error: "Interner Serverfehler." });
});

// Zusätzliches Sicherheitsnetz auf Prozessebene: verhindert, dass ein
// vergessener await/catch irgendwo den kompletten Node-Prozess beendet.
process.on("unhandledRejection", (reason) => {
  console.error("Unhandled Rejection:", reason);
});
process.on("uncaughtException", (err) => {
  console.error("Uncaught Exception:", err);
});

async function start() {
  const dbOk = await checkDbConnection();
  if (dbOk) {
    await runMigrations();
  } else {
    console.warn(
      "Start ohne Datenbank-Migration: DB nicht erreichbar. " +
        "Login/Registrierung funktionieren erst, sobald die DB verbunden ist."
    );
  }

  app.listen(PORT, () => {
    console.log(`Backend läuft auf http://localhost:${PORT}`);
  });
}

start();
