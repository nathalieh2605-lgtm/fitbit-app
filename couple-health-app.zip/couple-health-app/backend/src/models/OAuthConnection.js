import pool from "../config/db.js";
import { encrypt, decrypt } from "../services/tokenEncryption.js";

export async function saveGoogleConnection(userId, { accessToken, refreshToken, scope, expiresAt }) {
  const accessEnc = encrypt(accessToken);
  const refreshEnc = refreshToken ? encrypt(refreshToken) : null;

  const { rows } = await pool.query(
    `INSERT INTO oauth_connections (user_id, provider, access_token_encrypted, refresh_token_encrypted, scope, expires_at, updated_at)
     VALUES ($1, 'google', $2, $3, $4, $5, now())
     ON CONFLICT (user_id, provider) DO UPDATE SET
       access_token_encrypted = EXCLUDED.access_token_encrypted,
       -- Refresh-Token nur überschreiben, wenn Google ein neues geschickt hat
       -- (Google sendet es nicht bei jedem Refresh erneut)
       refresh_token_encrypted = COALESCE(EXCLUDED.refresh_token_encrypted, oauth_connections.refresh_token_encrypted),
       scope = EXCLUDED.scope,
       expires_at = EXCLUDED.expires_at,
       updated_at = now()
     RETURNING id`,
    [userId, accessEnc, refreshEnc, scope, expiresAt]
  );
  return rows[0];
}

export async function getGoogleConnection(userId) {
  const { rows } = await pool.query(
    `SELECT access_token_encrypted, refresh_token_encrypted, scope, expires_at
     FROM oauth_connections WHERE user_id = $1 AND provider = 'google'`,
    [userId]
  );
  if (!rows[0]) return null;

  try {
    return {
      accessToken: decrypt(rows[0].access_token_encrypted),
      refreshToken: rows[0].refresh_token_encrypted
        ? decrypt(rows[0].refresh_token_encrypted)
        : null,
      scope: rows[0].scope,
      expiresAt: rows[0].expires_at,
    };
  } catch (err) {
    // Beschädigter oder mit falschem Schlüssel verschlüsselter Datensatz
    // (z. B. nach einem TOKEN_ENCRYPTION_KEY-Wechsel). Wir behandeln das
    // als "nicht verbunden", statt die ganze Anfrage abstürzen zu lassen.
    console.error(`Konnte Google-Token für Nutzer ${userId} nicht entschlüsseln:`, err.message);
    return null;
  }
}

export async function deleteGoogleConnection(userId) {
  await pool.query(
    "DELETE FROM oauth_connections WHERE user_id = $1 AND provider = 'google'",
    [userId]
  );
}
