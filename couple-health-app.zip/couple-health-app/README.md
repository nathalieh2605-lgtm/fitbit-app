# Couple Health App

Private Health-Dashboard-App für zwei Nutzer, basierend auf der **Google Health API**
(Nachfolger der Fitbit Web API, aktueller Stand 09/2026).

Dies ist das **Grundgerüst (Schritt 4)**. Es ist lauffähig, enthält aber noch:
- keine echte Google-OAuth-Verbindung (kommt in Schritt 5/6)
- Mock-Daten für das Dashboard, klar gekennzeichnet als `MOCK`

## Voraussetzungen

- Node.js 20+
- Docker & Docker Compose (empfohlen) ODER lokal installiertes PostgreSQL 16+

## Lokal starten (mit Docker – empfohlen)

```bash
cp .env.example .env
docker compose up --build
```

- Backend: http://localhost:4000/health
- Frontend: http://localhost:5173

## Lokal starten (ohne Docker)

Backend:
```bash
cd backend
cp .env.example .env
npm install
npm run dev
```

Frontend (neues Terminal):
```bash
cd frontend
npm install
npm run dev
```

## Umgebungsvariablen (aktueller Stand, wird in Schritt 5/6 erweitert)

Siehe `.env.example` im Root sowie `backend/.env.example`.

| Variable | Zweck | Wo bekomme ich sie? |
|---|---|---|
| `DATABASE_URL` | Verbindung zu PostgreSQL | wird durch docker-compose automatisch gesetzt |
| `PORT` | Backend-Port | frei wählbar, Standard 4000 |
| `JWT_SECRET` | App-eigenes Login (noch nicht implementiert) | selbst generieren, z. B. `openssl rand -hex 32` |
| `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` | Google OAuth (folgt in Schritt 6) | Google Cloud Console → OAuth Client |

## Aktueller Stand nach Schritt 4

- ✅ Backend-Server läuft, `/health` antwortet
- ✅ PostgreSQL-Verbindung eingerichtet
- ✅ Frontend zeigt Grundnavigation (MEIN DASHBOARD | PARTNER | VERGLEICH)
- ✅ Dark/Light Mode Umschalter
- ✅ Platzhalter-Karten mit klar markierten MOCK-Daten
- ⬜ Noch keine echte Authentifizierung
- ⬜ Noch keine echte Google Health API-Anbindung

## Nächste Schritte

- Schritt 5: Authentication (App-Login)
- Schritt 6: Google Health API OAuth-Anbindung
